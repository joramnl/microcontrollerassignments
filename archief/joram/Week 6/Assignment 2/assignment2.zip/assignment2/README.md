# Usage

Run `make` to compile and run the program.
